(function() {
  riot.mount('username-input');
  riot.mount('password-input',{
    isReg : true
  });
  $('#registerBtn').on('click', function() {

  });
})();