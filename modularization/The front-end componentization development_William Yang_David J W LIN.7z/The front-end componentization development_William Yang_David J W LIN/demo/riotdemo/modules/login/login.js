(function() {
  riot.mount('username-input');
  riot.mount('password-input');
  $('#loginBtn').on('click', function() {

  });
})();